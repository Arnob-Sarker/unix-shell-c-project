#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <dirent.h>

#define MAX_INPUT 1024
#define MAX_ARGS 64
#define MAX_COMMANDS 16
#define HIST_SIZE 200

char* hist[HIST_SIZE];
int hist_cnt = 0;

// Functions
void print_prompt();
void read_input(char* input);
void exec_command(char* command);
void exec_piped_cmd(char** commands, int count);
void add_to_hist(char* cmd);
void show_hist();
void sig_handler(int sig);

void print_prompt() {
    printf("sh> ");
    fflush(stdout);
}

void read_input(char* input) {
    if (fgets(input, MAX_INPUT, stdin) == NULL) {
        if (feof(stdin)) {
            printf("\n");
            exit(0);
        } else {
            perror("fgets");
            exit(1);
        }
    }
    input[strcspn(input, "\n")] = '\0';
}

void exec_command(char* command) {
    char* args[MAX_ARGS];
    int arg_cnt = 0;
    char* input_file = NULL;
    char* output_file = NULL;
    char* append_file = NULL;
    int redirect_input = 0, redirect_output = 0, append_mode = 0;
    
    //redirection
    char* token = strtok(command, " ");
    while (token != NULL && arg_cnt < MAX_ARGS - 1) {
        if (strcmp(token, "<") == 0) {
            redirect_input = 1;
            token = strtok(NULL, " ");
            if (token) input_file = token;
        } else if (strcmp(token, ">") == 0) {
            redirect_output = 1;
            token = strtok(NULL, " ");
            if (token) output_file = token;
        } else if (strcmp(token, ">>") == 0) {
            append_mode = 1;
            token = strtok(NULL, " ");
            if (token) append_file = token;
        } else {
            args[arg_cnt++] = token;
        }
        token = strtok(NULL, " ");
    }
    args[arg_cnt] = NULL;

    //built-in commands
    if (arg_cnt > 0 && handle_builtin(args, arg_cnt)) {
        return;
    }
    
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return;
    } else if (pid == 0) {        
        //input redirection
        if (redirect_input && input_file) {
            int fd = open(input_file, O_RDONLY);
            if (fd < 0) {
                perror("open input");
                exit(1);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }
        
        //output redirection overwrite
        if (redirect_output && output_file) {
            int fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd < 0) {
                perror("open output");
                exit(1);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
        }
        
        //output redirection append
        if (append_mode && append_file) {
            int fd = open(append_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
            if (fd < 0) {
                perror("open append");
                exit(1);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
        }
        
        //external command
        execvp(args[0], args);
        perror("execvp");
        exit(1);
    } else {
        int status;
        waitpid(pid, &status, 0);
    }
}

//handle built-in commands
int handle_builtin(char** args, int arg_cnt) {
    if (strcmp(args[0], "cd") == 0) {
        if (arg_cnt < 2) {
            chdir(getenv("HOME"));
        } else {
            if (chdir(args[1]) != 0) {
                perror("cd");
            }
        }
        return 1;
    }
    else if (strcmp(args[0], "pwd") == 0) {
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd)) != NULL) {
            printf("%s\n", cwd);
        } else {
            perror("pwd");
        }
        return 1;
    }
    else if (strcmp(args[0], "exit") == 0) {
        exit(0);
    }
    return 0; 
}

void exec_piped_cmd(char** commands, int count) {
    int fd[2];
    pid_t pid;
    int in = STDIN_FILENO;  
    int status;
    int i;

    for (i = 0; i < count; i++) {
        if (i < count - 1) {
            if (pipe(fd) < 0) {
                perror("pipe");
                return;
            }
        }
        pid = fork();
        if (pid < 0) {
            perror("fork");
            return;
        } else if (pid == 0) {
            if (i > 0) {
                dup2(in, STDIN_FILENO);
                close(in);
            }

            if (i < count - 1) {
                dup2(fd[1], STDOUT_FILENO);
                close(fd[1]);
            }
            if (i < count - 1) close(fd[0]);

            char* args[MAX_ARGS];
            int arg_cnt = 0;
            char* token = strtok(commands[i], " ");
            while (token && arg_cnt < MAX_ARGS - 1) {
                args[arg_cnt++] = token;
                token = strtok(NULL, " ");
            }
            args[arg_cnt] = NULL;

            if (!handle_builtin(args, arg_cnt)) {
                execvp(args[0], args);
                perror("execvp");
                exit(EXIT_FAILURE);
            }
            exit(EXIT_SUCCESS);
        } else {
            if (i > 0) close(in);       
            if (i < count - 1) {
                close(fd[1]);           
                in = fd[0];          
            }
        }
    }
    for (i = 0; i < count; i++) {
        wait(&status);
    }
}

void add_to_hist(char* cmd) {
    if (hist_cnt < HIST_SIZE) {
        hist[hist_cnt++] = strdup(cmd);
    } else {
        free(hist[0]);
        for (int i = 0; i < HIST_SIZE - 1; i++) {
            hist[i] = hist[i + 1];
        }
        hist[HIST_SIZE - 1] = strdup(cmd);
    }
}

void show_hist() {
    for (int i = 0; i < hist_cnt; i++) {
        printf("%d: %s\n", i + 1, hist[i]);
    }
}

void sig_handler(int sig) {
    printf("\n");
    print_prompt();
    fflush(stdout);
}

int main() {
    signal(SIGINT, sig_handler);
    char input[MAX_INPUT];
    int prev_status = 0; 
    
    while (1) {
        print_prompt();
        read_input(input);
        
        if (strcmp(input, "exit") == 0) break;
        if (strlen(input) == 0) continue;
        
        add_to_hist(input);
        if (strcmp(input, "history") == 0) {
            show_hist();
            continue;
        } 
        //(;, &&, ||)
        char* sequences[MAX_COMMANDS];
        int seq_cnt = 0;
        //semicolons
        char* saveptr;
        char* token = strtok_r(input, ";", &saveptr);
        while (token && seq_cnt < MAX_COMMANDS) {
            sequences[seq_cnt++] = token;
            token = strtok_r(NULL, ";", &saveptr);
        }
        for (int i = 0; i < seq_cnt; i++) {
            //(&& and ||)
            char* logical_parts[MAX_COMMANDS];
            char* logical_ops[MAX_COMMANDS] = {NULL};
            int logical_cnt = 0;
        
            char seq_copy[MAX_INPUT];
            strcpy(seq_copy, sequences[i]);
            char* logical_token = strtok(seq_copy, "&|");
            
            while (logical_token && logical_cnt < MAX_COMMANDS) {
                while (*logical_token == ' ') logical_token++;
                char* end = logical_token + strlen(logical_token) - 1;
                while (end > logical_token && *end == ' ') end--;
                *(end + 1) = '\0';
                
                if (strlen(logical_token) > 0) {
                    logical_parts[logical_cnt] = strdup(logical_token);
                   
                    if (logical_token + strlen(logical_token) < seq_copy + strlen(sequences[i])) {
                        char* op_pos = logical_token + strlen(logical_token);
                        while (*op_pos == ' ') op_pos++;
                        if (*op_pos == '&' && *(op_pos+1) == '&') {
                            logical_ops[logical_cnt] = "&&";
                        } else if (*op_pos == '|' && *(op_pos+1) == '|') {
                            logical_ops[logical_cnt] = "||";
                        }
                    }
                    
                    logical_cnt++;
                }
                logical_token = strtok(NULL, "&|");
            }
            
            for (int j = 0; j < logical_cnt; j++) {
                if (j > 0 && logical_ops[j-1] != NULL) {
                    if (strcmp(logical_ops[j-1], "&&") == 0 && prev_status != 0) {
                        free(logical_parts[j]);
                        continue; 
                    }
                    if (strcmp(logical_ops[j-1], "||") == 0 && prev_status == 0) {
                        free(logical_parts[j]);
                        continue; 
                    }
                }

                char* pipes[MAX_COMMANDS];
                int pipe_cnt = 0;
                char* pipe_token = strtok(logical_parts[j], "|");
                
                while (pipe_token && pipe_cnt < MAX_COMMANDS) {
                   
                    while (*pipe_token == ' ') pipe_token++;
                    char* end = pipe_token + strlen(pipe_token) - 1;
                    while (end > pipe_token && *end == ' ') end--;
                    *(end + 1) = '\0';
                    
                    pipes[pipe_cnt++] = pipe_token;
                    pipe_token = strtok(NULL, "|");
                }
                if (pipe_cnt > 1) {
                    exec_piped_cmd(pipes, pipe_cnt);
                } else {
                    exec_command(logical_parts[j]);
                }
                int status;
                wait(&status);
                prev_status = WEXITSTATUS(status);
                
                free(logical_parts[j]);
            }
        }
    }
    for (int i = 0; i < hist_cnt; i++) {
        free(hist[i]);
    }
    return 0;
}
